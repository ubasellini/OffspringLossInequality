# Inequality in Offspring Loss

This repository containts the routines to replicate the analysis of the manuscript: "When do parents bury a child? Quantifying uncertainty in the parental age at offspring loss"
